import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import shutil # For making a backup of the CSV

# --- Configuration and Setup ---

# Get the directory where the current Python script is located.
# This ensures that 'plots' folder and backup CSV are always created relative to the script's location.
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# Define the path for the directory where plots will be saved.
PLOTS_DIR = os.path.join(SCRIPT_DIR, 'plots')

# Define the full path to the dataset CSV file.
# IMPORTANT: Users MUST update this path to their actual dataset location.
DATASET_PATH = r"E:\Learning\samsung_python\project\dataset_project.csv"

# Define the path for the backup of the original dataset.
# This will now be created in the same directory as the script.
BACKUP_DATASET_PATH = os.path.join(SCRIPT_DIR, 'dataset_project_backup.csv')

# Create the 'plots' directory if it does not already exist.
if not os.path.exists(PLOTS_DIR):
    os.makedirs(PLOTS_DIR)
    print(f"Created directory for plots: {PLOTS_DIR}")

# Set the default style for all Seaborn plots.
sns.set(style="whitegrid")

# Global DataFrame variable. This will hold the preprocessed data
# and is loaded once at the start of the program to avoid redundant processing.
df = None

# --- Helper Functions ---

def load_and_preprocess_data(file_path):
    """
    Loads the dataset from the specified file path and performs all necessary preprocessing steps.
    This includes date conversion, feature engineering (Year, Month, Season, Age_Group, BMI_Category).
    A backup of the original CSV is created before loading to prevent accidental data loss.

    Args:
        file_path (str): The absolute or relative path to the CSV dataset file.

    Returns:
        pandas.DataFrame: The preprocessed DataFrame, or None if an error occurs during loading.
    """
    global df # Declare 'df' as global to modify the global DataFrame variable

    # If data is already loaded, return it to prevent reprocessing.
    if df is not None:
        return df

    try:
        # Create a backup of the original dataset before attempting to load.
        # This is a safety measure.
        if os.path.exists(file_path):
            shutil.copy(file_path, BACKUP_DATASET_PATH)
            print(f"Backup of original dataset created at: {BACKUP_DATASET_PATH}")
        
        # Load the dataset into a Pandas DataFrame.
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        print(f"Error: The dataset file '{file_path}' was not found. Please check the path.")
        return None
    except Exception as e:
        print(f"An unexpected error occurred while loading the data: {e}")
        return None

    # --- Data Preprocessing Steps ---

    # Convert the 'Date_of_Delivery' column to datetime objects for easier date manipulation.
    df['Date_of_Delivery'] = pd.to_datetime(df['Date_of_Delivery'])

    # Extract the 'Year' and 'Month' (as integers) from 'Date_of_Delivery'.
    df['Year'] = df['Date_of_Delivery'].dt.year
    df['Month'] = df['Date_of_Delivery'].dt.month

    # Adding Season column based on Month (using conditions for clarity)
    conditions = [
        (df['Month'] == 12) | (df['Month'] == 1) | (df['Month'] == 2), # Winter: Dec, Jan, Feb
        (df['Month'] >= 3) & (df['Month'] <= 5), # Spring: Mar, Apr, May
        (df['Month'] >= 6) & (df['Month'] <= 8), # Monsoon: Jun, Jul, Aug
        (df['Month'] >= 9) & (df['Month'] <= 11) # Autumn: Sep, Oct, Nov
    ]
    choices = ['Winter', 'Spring', 'Monsoon', 'Autumn']
    df['Season'] = pd.Series(pd.NA, index=df.index, dtype=str) # Initialize with nullable string type
    for cond, choice in zip(conditions, choices):
        df.loc[cond, 'Season'] = choice

    # Create 'Age_Group' categories from 'Mother_Age' using pd.cut for binning.
    df['Age_Group'] = pd.cut(df['Mother_Age'], bins=[0, 20, 30, 40, 100],
                             labels=['<20', '20-30', '30-40', '40+'])

    # Create 'BMI_Category' categories from 'Mother_BMI' using pd.cut for binning.
    df['BMI_Category'] = pd.cut(df['Mother_BMI'], bins=[0, 18.5, 25, 30, 100],
                                labels=['Underweight', 'Normal', 'Overweight', 'Obese'])

    print("Preprocessed DataFrame head:")
    print(df.head()) # Print the head of the processed DataFrame for verification
    return df

def save_plot(fig, plot_name):
    """
    Saves a Matplotlib figure to the predefined PLOTS_DIR as a PNG image.
    Note: plt.close(fig) is intentionally removed here so that plt.show() can display it.

    Args:
        fig (matplotlib.figure.Figure): The Matplotlib figure object to save.
        plot_name (str): The desired filename (without extension) for the plot.
    """
    file_path = os.path.join(PLOTS_DIR, f"{plot_name}.png")
    fig.savefig(file_path, bbox_inches='tight') # Save the figure, tightly bounding the content
    print(f"Saved plot: {file_path}")

# --- Visualization Functions ---
# Each function generates a specific plot, saves it, and then displays it.

def plot_delivery_type_distribution(df_local):
    """Generates and saves a countplot and a pie chart for Delivery Type Distribution, then shows them."""
    print("\n--- 1. Delivery Type Distribution ---")
    # Countplot for Delivery Type
    fig1, ax1 = plt.subplots(figsize=(6, 4))
    sns.countplot(x='Delivery_Type', data=df_local, palette='Set2', ax=ax1)
    ax1.set_title("Count of Delivery Types")
    ax1.set_xlabel("Delivery Type")
    ax1.set_ylabel("Count")
    save_plot(fig1, "delivery_type_countplot")
    plt.show() # Show the countplot

    # Pie chart for Delivery Type distribution
    delivery_counts = df_local['Delivery_Type'].value_counts()
    fig2, ax2 = plt.subplots(figsize=(6, 6))
    ax2.pie(delivery_counts, labels=delivery_counts.index, autopct='%1.1f%%', colors=['lightgreen', 'lightcoral'])
    ax2.set_title("Delivery Type Distribution")
    save_plot(fig2, "delivery_type_piechart")
    plt.show() # Show the pie chart

def plot_institutional_comparison(df_local):
    """Generates and saves a countplot for Delivery Type by Hospital Type, then shows it."""
    print("\n--- 2. Institutional Comparison ---")
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.countplot(x='Hospital_Type', hue='Delivery_Type', data=df_local, palette='Set3', ax=ax)
    ax.set_title("Delivery Type by Hospital Type")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')
    ax.set_xlabel("Hospital Type")
    ax.set_ylabel("Count")
    ax.legend(title="Delivery Type")
    fig.tight_layout()
    save_plot(fig, "institutional_comparison")
    plt.show() # Show the plot

def plot_regional_disparity(df_local):
    """Generates and saves a countplot for Delivery Type by Region, then shows it."""
    print("\n--- 3. Regional Disparity in Delivery Type ---")
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.countplot(x='Region', hue='Delivery_Type', data=df_local, palette='pastel', ax=ax)
    ax.set_title("Delivery Type by Region")
    ax.set_xlabel("Region")
    ax.set_ylabel("Count")
    ax.legend(title='Delivery Type')
    fig.tight_layout()
    save_plot(fig, "regional_disparity")
    plt.show() # Show the plot

def plot_seasonal_effect(df_local):
    """Generates and saves a countplot for Delivery Type by Season, then shows it."""
    print("\n--- 4. Seasonal Effect on Delivery Type ---")
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.countplot(x='Season', hue='Delivery_Type', data=df_local, palette='Paired', ax=ax)
    ax.set_title("Delivery Type by Season")
    ax.set_xlabel("Season")
    ax.set_ylabel("Count")
    fig.tight_layout()
    save_plot(fig, "seasonal_effect")
    plt.show() # Show the plot

def plot_maternal_age_vs_delivery_type(df_local):
    """Generates and saves a countplot for Delivery Type by Mother's Age Group, then shows it."""
    print("\n--- 5. Maternal Age Group vs Delivery Type ---")
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.countplot(x='Age_Group', hue='Delivery_Type', data=df_local, palette='Accent', ax=ax)
    ax.set_title("Delivery Type by Mother's Age Group")
    ax.set_xlabel("Age Group")
    ax.set_ylabel("Count")
    fig.tight_layout()
    save_plot(fig, "maternal_age_vs_delivery_type")
    plt.show() # Show the plot

def plot_nicu_admission_rate(df_local):
    """Generates and saves a stacked bar chart for NICU Admission by Delivery Type, then shows it."""
    print("\n--- 6. NICU Admission Rate (Stacked Bar Chart) ---")
    nicu_table = pd.crosstab(df_local['Delivery_Type'], df_local['NICU_Admission'])
    fig, ax = plt.subplots(figsize=(8,4))
    nicu_table.plot(kind='bar', stacked=True, colormap='Set2', ax=ax)
    ax.set_title("NICU Admission by Delivery Type")
    ax.set_xlabel("Delivery Type")
    ax.set_ylabel("Count")
    ax.legend(title="NICU Admission")
    fig.tight_layout()
    save_plot(fig, "nicu_admission_rate")
    plt.show() # Show the plot

def plot_medical_complication_impact(df_local):
    """Generates and saves a countplot for Delivery Type by Medical Complication, then shows it."""
    print("\n--- 7. Medical Complication Impact ---")
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.countplot(x='Medical_Complication', hue='Delivery_Type', data=df_local, palette='Set1', ax=ax)
    ax.set_title("Delivery Type by Medical Complication")
    ax.set_xlabel("Medical Complication")
    ax.set_ylabel("Count")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')
    fig.tight_layout()
    save_plot(fig, "medical_complication_impact")
    plt.show() # Show the plot

def plot_bmi_vs_delivery_type(df_local):
    """Generates and saves a countplot for Delivery Type by Mother's BMI Category, then shows it."""
    print("\n--- 8. BMI vs Delivery Type ---")
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.countplot(x='BMI_Category', hue='Delivery_Type', data=df_local, palette='Set3', ax=ax)
    ax.set_title("Delivery Type by Mother's BMI Category")
    ax.set_xlabel("BMI Category")
    ax.set_ylabel("Count")
    fig.tight_layout()
    save_plot(fig, "bmi_vs_delivery_type")
    plt.show() # Show the plot

def plot_child_weight_vs_delivery_type(df_local):
    """Generates and saves a box plot for Child Weight by Delivery Type, then shows it."""
    print("\n--- 9. Child Weight vs Delivery Type (Box Plot) ---")
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.boxplot(x='Delivery_Type', y='Child_Weight_kg', data=df_local, palette='Set2', ax=ax)
    ax.set_title("Child Weight by Delivery Type")
    ax.set_xlabel("Delivery Type")
    ax.set_ylabel("Child Weight (kg)")
    fig.tight_layout()
    save_plot(fig, "child_weight_vs_delivery_type")
    plt.show() # Show the plot

# --- Analysis Questions Functions ---

def analyze_csection_by_region(df_local):
    """
    Analyzes C-section deliveries by Region, generates a bar plot, and returns a textual summary.
    The plot is also shown.
    """
    print("\n--- Q1) Which part of the country has more C-section deliveries? ---")
    region_c_sections = df_local[df_local['Delivery_Type'] == 'C-section']['Region'].value_counts()

    fig, ax = plt.subplots(figsize=(8, 5))
    region_c_sections.plot(kind='bar', title='C-section Deliveries by Region', xlabel='Region', ylabel='Count', color='salmon', ax=ax)
    fig.tight_layout()
    save_plot(fig, "csection_by_region")
    plt.show() # Show the plot

    return "C-section Deliveries by Region:\n" + region_c_sections.to_string()

def analyze_csection_by_hospital(df_local):
    """
    Analyzes C-section deliveries by Hospital Name, generates a bar plot of top hospitals,
    and returns a textual summary. The plot is also shown.
    """
    print("\n--- Q2) Which hospitals have more C-section deliveries? ---")
    hospital_c_sections = df_local[df_local['Delivery_Type'] == 'C-section']['Hospital_Name'].value_counts()

    fig, ax = plt.subplots(figsize=(8, 6))
    hospital_c_sections.head(10).plot(kind='barh', title='Top Hospitals by C-section Deliveries', color='skyblue', ax=ax)
    ax.set_xlabel('Number of C-sections')
    ax.set_ylabel('Hospital Name')
    fig.tight_layout()
    save_plot(fig, "csection_by_hospital")
    plt.show() # Show the plot

    return "Top 10 Hospitals by C-section Deliveries:\n" + hospital_c_sections.head(10).to_string()

def analyze_csection_relation_with_season(df_local):
    """
    Analyzes the relationship between C-section delivery and Season, generates a stacked bar plot,
    and returns a textual summary of percentages. The plot is also shown.
    """
    print("\n--- Q3) Does C-section delivery have any relation with Season? ---")
    season_table = pd.crosstab(df_local['Season'], df_local['Delivery_Type'], normalize='index') * 100

    fig, ax = plt.subplots(figsize=(8, 5))
    season_table.plot(kind='bar', stacked=True, colormap='Paired', title='Delivery Type by Season (%)', ax=ax)
    ax.set_ylabel("Percentage")
    fig.tight_layout()
    save_plot(fig, "csection_by_season")
    plt.show() # Show the plot

    return "Percentage of Delivery Types by Season:\n" + season_table.round(1).to_string()

def analyze_second_child_normal_after_csection(df_local):
    """
    Calculates the percentage of 2nd child births that were normal when the 1st was a C-section.
    Also generates a pie chart for the counts of delivery types in this specific subset.
    Returns the textual analysis. The plot is also shown.
    """
    print("\n--- Q4) What percentage of 2nd child births were normal when 1st was C-section? ---")

    mask = (df_local['Child_Birth_Order'] == 2) & (df_local['Previous_Delivery_Type'] == 'C-section')
    subset = df_local[mask]

    total_second_after_csection = subset.shape[0]
    normal_now = subset[subset['Delivery_Type'] == 'Normal'].shape[0]
    percentage = (normal_now / total_second_after_csection) * 100 if total_second_after_csection > 0 else 0

    delivery_counts = subset['Delivery_Type'].value_counts()
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.pie(delivery_counts,
           labels=delivery_counts.index,
           autopct='%1.1f%%',
           startangle=90,
           colors=['lightgreen', 'lightcoral'])
    ax.set_title("2nd Child Delivery Type (After 1st C-section)")
    save_plot(fig, "q4_delivery_type_counts")
    plt.show() # Show the plot

    return f"Percentage of 2nd child births that were normal after 1st C-section: {percentage:.2f}%"

# --- Main Program Flow (Console Menu) ---

def run_all_visualizations():
    """Executes all defined visualization functions, showing each plot."""
    global df
    if df is None:
        print("DataFrame not loaded. Attempting to load data...")
        load_and_preprocess_data(DATASET_PATH)
        if df is None:
            return

    print("\n--- Generating All Visualizations and Saving Plots ---")
    plot_delivery_type_distribution(df)
    plot_institutional_comparison(df)
    plot_regional_disparity(df)
    plot_seasonal_effect(df)
    plot_maternal_age_vs_delivery_type(df)
    plot_nicu_admission_rate(df)
    plot_medical_complication_impact(df)
    plot_bmi_vs_delivery_type(df)
    plot_child_weight_vs_delivery_type(df)
    print("\nAll visualizations generated and saved to the 'plots' folder. Please close plot windows to continue.")

def run_specific_visualization():
    """Allows the user to select and run a single visualization, showing the plot."""
    global df
    if df is None:
        print("DataFrame not loaded. Attempting to load data...")
        load_and_preprocess_data(DATASET_PATH)
        if df is None:
            return

    print("\n--- Select a Visualization to Generate ---")
    print("1. Delivery Type Distribution")
    print("2. Institutional Comparison")
    print("3. Regional Disparity in Delivery Type")
    print("4. Seasonal Effect on Delivery Type")
    print("5. Maternal Age Group vs Delivery Type")
    print("6. NICU Admission Rate")
    print("7. Medical Complication Impact")
    print("8. BMI vs Delivery Type")
    print("9. Child Weight vs Delivery Type")
    choice = input("Enter visualization number (1-9): ")

    viz_functions = {
        '1': plot_delivery_type_distribution,
        '2': plot_institutional_comparison,
        '3': plot_regional_disparity,
        '4': plot_seasonal_effect,
        '5': plot_maternal_age_vs_delivery_type,
        '6': plot_nicu_admission_rate,
        '7': plot_medical_complication_impact,
        '8': plot_bmi_vs_delivery_type,
        '9': plot_child_weight_vs_delivery_type,
    }

    if choice in viz_functions:
        viz_functions[choice](df)
        print("\nPlot generated. Please close the plot window to continue.")
    else:
        print("Invalid choice. Please enter a number from 1 to 9.")

def run_all_analyses():
    """Executes all defined analysis question functions, showing plots and printing results."""
    global df
    if df is None:
        print("DataFrame not loaded. Attempting to load data...")
        load_and_preprocess_data(DATASET_PATH)
        if df is None:
            return

    print("\n--- Running All Analysis Questions ---")
    q1_output = analyze_csection_by_region(df)
    q2_output = analyze_csection_by_hospital(df)
    q3_output = analyze_csection_relation_with_season(df)
    q4_output = analyze_second_child_normal_after_csection(df)

    print("\n--- TEXTUAL ANALYSIS RESULTS (Copy these for HTML dashboard if you use one) ---")
    print("Q1 Output:\n", q1_output)
    print("\nQ2 Output:\n", q2_output)
    print("\nQ3 Output:\n", q3_output)
    print("\nQ4 Output:\n", q4_output)
    print("\nAll analysis plots generated. Please close plot windows to continue.")

def run_specific_analysis():
    """Allows the user to select and run a single analysis question, showing the plot."""
    global df
    if df is None:
        print("DataFrame not loaded. Attempting to load data...")
        load_and_preprocess_data(DATASET_PATH)
        if df is None:
            return

    print("\n--- Select an Analysis Question to Run ---")
    print("1. C-section deliveries by Region")
    print("2. C-section deliveries by Hospital")
    print("3. C-section relation with Season")
    print("4. 2nd child normal birth after 1st C-section percentage")
    choice = input("Enter analysis number (1-4): ")

    analysis_functions = {
        '1': analyze_csection_by_region,
        '2': analyze_csection_by_hospital,
        '3': analyze_csection_relation_with_season,
        '4': analyze_second_child_normal_after_csection,
    }

    if choice in analysis_functions:
        output = analysis_functions[choice](df)
        print("\n--- ANALYSIS RESULT ---")
        print(output)
        print("\nPlot generated. Please close the plot window to continue.")
    else:
        print("Invalid choice. Please enter a number from 1 to 4.")

def main():
    """
    The main function that orchestrates the program.
    It loads the data once and then presents an interactive menu to the user
    for performing various analyses and visualizations.
    """
    global df # Ensure 'df' is accessible and modifiable globally

    # Attempt to load and preprocess data at the very beginning of the program.
    # If this fails, the program will exit.
    print("Attempting to load and preprocess data...")
    load_and_preprocess_data(DATASET_PATH)
    if df is None:
        print("Failed to load or preprocess data. Please check the dataset path and format. Exiting program.")
        return

    # Main interactive loop for the console menu.
    while True:
        print("\n--- Normal Vs C-section Delivery Analysis Menu ---")
        print("1. Run All Visualizations (generates all plots in 'plots/' folder and shows them)")
        print("2. Run Specific Visualization (generates a specific plot and shows it)")
        print("3. Run All Analysis Questions (generates plots & prints text to console, shows plots)")
        print("4. Run Specific Analysis Question (generates a specific plot & prints text, shows plot)")
        print("0. Exit Application")

        choice = input("Enter your choice: ")

        if choice == '1':
            run_all_visualizations()
        elif choice == '2':
            run_specific_visualization()
        elif choice == '3':
            run_all_analyses()
        elif choice == '4':
            run_specific_analysis()
        elif choice == '0':
            print("Exiting application. Goodbye!")
            break # Exit the loop and end the program
        else:
            print("Invalid choice. Please enter a number between 0 and 4.")

# Entry point of the script.
# This ensures that main() is called only when the script is executed directly.
if __name__ == "__main__":
    main()
