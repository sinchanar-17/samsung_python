import matplotlib.pyplot as plt
import seaborn as sns
import os

def save_plot(fig, plot_name):
    file_path = os.path.join('plots', f"{plot_name}.png")
    fig.savefig(file_path, bbox_inches='tight')
    print(f"Saved plot: {file_path}")

def plot_child_weight_vs_delivery_type(df_local):
    print("\n--- 9. Child Weight vs Delivery Type (Box Plot) ---")

    fig, ax = plt.subplots(figsize=(7, 4))
    sns.boxplot(x='Delivery_Type', y='Child_Weight_kg', data=df_local, palette='Set2', ax=ax)
    ax.set_title("Child Weight by Delivery Type")
    ax.set_xlabel("Delivery Type")
    ax.set_ylabel("Child Weight (kg)")
    fig.tight_layout()
    save_plot(fig, "child_weight_vs_delivery_type")
    plt.show()
