import matplotlib.pyplot as plt
import seaborn as sns
import os

def save_plot(fig, plot_name):
    file_path = os.path.join('plots', f"{plot_name}.png")
    fig.savefig(file_path, bbox_inches='tight')
    print(f"Saved plot: {file_path}")

def plot_delivery_type_distribution(df_local):
    print("\n--- 1. Delivery Type Distribution ---")

    fig1, ax1 = plt.subplots(figsize=(6, 4))
    sns.countplot(x='Delivery_Type', data=df_local, palette='Set2', ax=ax1)
    ax1.set_title("Count of Delivery Types")
    ax1.set_xlabel("Delivery Type")
    ax1.set_ylabel("Count")
    save_plot(fig1, "delivery_type_countplot")
    plt.show()

    delivery_counts = df_local['Delivery_Type'].value_counts()
    fig2, ax2 = plt.subplots(figsize=(6, 6))
    ax2.pie(delivery_counts, labels=delivery_counts.index, autopct='%1.1f%%', colors=['lightgreen', 'lightcoral'])
    ax2.set_title("Delivery Type Distribution")
    save_plot(fig2, "delivery_type_piechart")
    plt.show()
