import matplotlib.pyplot as plt
import seaborn as sns
import os

def save_plot(fig, plot_name):
    file_path = os.path.join('plots', f"{plot_name}.png")
    fig.savefig(file_path, bbox_inches='tight')
    print(f"Saved plot: {file_path}")

def plot_maternal_age_vs_delivery_type(df_local):
    print("\n--- 5. Maternal Age Group vs Delivery Type ---")

    fig, ax = plt.subplots(figsize=(7, 4))
    sns.countplot(x='Age_Group', hue='Delivery_Type', data=df_local, palette='Accent', ax=ax)
    ax.set_title("Delivery Type by Mother's Age Group")
    ax.set_xlabel("Age Group")
    ax.set_ylabel("Count")
    fig.tight_layout()
    save_plot(fig, "maternal_age_vs_delivery_type")
    plt.show()
