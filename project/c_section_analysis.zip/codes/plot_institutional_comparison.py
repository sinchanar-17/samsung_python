import matplotlib.pyplot as plt
import seaborn as sns
import os

def save_plot(fig, plot_name):
    file_path = os.path.join('plots', f"{plot_name}.png")
    fig.savefig(file_path, bbox_inches='tight')
    print(f"Saved plot: {file_path}")

def plot_institutional_comparison(df_local):
    print("\n--- 2. Institutional Comparison ---")

    fig, ax = plt.subplots(figsize=(8, 5))
    sns.countplot(x='Hospital_Type', hue='Delivery_Type', data=df_local, palette='Set3', ax=ax)
    ax.set_title("Delivery Type by Hospital Type")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')
    ax.set_xlabel("Hospital Type")
    ax.set_ylabel("Count")
    ax.legend(title="Delivery Type")
    fig.tight_layout()
    save_plot(fig, "institutional_comparison")
    plt.show()
