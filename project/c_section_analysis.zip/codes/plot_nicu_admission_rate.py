import matplotlib.pyplot as plt
import pandas as pd
import os

def save_plot(fig, plot_name):
    file_path = os.path.join('plots', f"{plot_name}.png")
    fig.savefig(file_path, bbox_inches='tight')
    print(f"Saved plot: {file_path}")

def plot_nicu_admission_rate(df_local):
    print("\n--- 6. NICU Admission Rate (Stacked Bar Chart) ---")

    nicu_table = pd.crosstab(df_local['Delivery_Type'], df_local['NICU_Admission'])

    fig, ax = plt.subplots(figsize=(8, 4))
    nicu_table.plot(kind='bar', stacked=True, colormap='Set2', ax=ax)
    ax.set_title("NICU Admission by Delivery Type")
    ax.set_xlabel("Delivery Type")
    ax.set_ylabel("Count")
    ax.legend(title="NICU Admission")
    fig.tight_layout()
    save_plot(fig, "nicu_admission_rate")
    plt.show()
