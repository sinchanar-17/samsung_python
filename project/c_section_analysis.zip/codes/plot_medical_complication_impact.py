import matplotlib.pyplot as plt
import seaborn as sns
import os

def save_plot(fig, plot_name):
    file_path = os.path.join('plots', f"{plot_name}.png")
    fig.savefig(file_path, bbox_inches='tight')
    print(f"Saved plot: {file_path}")

def plot_medical_complication_impact(df_local):
    print("\n--- 7. Medical Complication Impact ---")

    fig, ax = plt.subplots(figsize=(8, 5))
    sns.countplot(x='Medical_Complication', hue='Delivery_Type', data=df_local, palette='Set1', ax=ax)
    ax.set_title("Delivery Type by Medical Complication")
    ax.set_xlabel("Medical Complication")
    ax.set_ylabel("Count")
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')
    fig.tight_layout()
    save_plot(fig, "medical_complication_impact")
    plt.show()
